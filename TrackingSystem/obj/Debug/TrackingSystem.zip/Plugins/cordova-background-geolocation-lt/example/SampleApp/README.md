Example Background GeoLocation app.
=============================================

